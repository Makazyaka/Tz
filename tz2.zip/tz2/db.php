<?php
// Настройки для подключения к базе данных
$host = 'localhost';
$dbname = 'employees_db'; // Имя базы данных
$user = 'root'; // Имя пользователя базы данных
$pass = ''; // Пароль для базы данных 

try {
    // Создание объекта PDO для подключения к базе данных
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Обработка ошибки при подключении к базе данных
    echo 'Connection failed: ' . $e->getMessage();
}
?>