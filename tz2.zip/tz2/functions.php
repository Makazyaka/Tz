<?php
// Получение всех сотрудников с опциональной фильтрацией по отделу и должности
function getAllEmployees($pdo, $department = null, $position = null, $search = null) {
    $query = "SELECT * FROM employees WHERE 1=1";
    
    if ($department) {
        $query .= " AND department = :department";
    }
    if ($position) {
        $query .= " AND position = :position";
    }
    if ($search) {
        $query .= " AND full_name LIKE :search";
    }
    
    $stmt = $pdo->prepare($query);
    
    if ($department) {
        $stmt->bindParam(':department', $department);
    }
    if ($position) {
        $stmt->bindParam(':position', $position);
    }
    if ($search) {
        $search = "%$search%";
        $stmt->bindParam(':search', $search);
    }
    
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Добавление нового сотрудника
function addEmployee($pdo, $data) {
    // Для отладки выводим массив данных
    var_dump($data); // Этот вывод поможет увидеть, что именно передается в запрос
    
    $stmt = $pdo->prepare("INSERT INTO employees (full_name, birth_date, passport_number, contact_info, address, department, position, salary, hire_date) 
                           VALUES (:full_name, :birth_date, :passport_number, :contact_info, :address, :department, :position, :salary, :hire_date)");
    $stmt->execute($data);
}

// Получение информации о сотруднике по ID
function getEmployeeById($pdo, $id) {
    $stmt = $pdo->prepare("SELECT * FROM employees WHERE id = :id");
    $stmt->execute(['id' => $id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Обновление информации о сотруднике
function updateEmployee($pdo, $id, $data) {
    $stmt = $pdo->prepare("UPDATE employees SET full_name = :full_name, birth_date = :birth_date, passport_number = :passport_number, 
                           contact_info = :contact_info, address = :address, department = :department, position = :position, salary = :salary
                           WHERE id = :id AND is_fired = 0");
    $data['id'] = $id;
    $stmt->execute($data);
}

// Увольнение сотрудника
function fireEmployee($pdo, $id) {
    $stmt = $pdo->prepare("UPDATE employees SET is_fired = 1 WHERE id = :id");
    $stmt->execute(['id' => $id]);
}


function getEmployees($pdo, $filter = '') {
    try {
        $query = "SELECT * FROM employees";
        
        // Добавляем условие фильтрации
        if (!empty($filter)) {
            $query .= " WHERE full_name LIKE :filter OR department LIKE :filter";
        }

        $stmt = $pdo->prepare($query);
        
        // Если фильтр установлен, подготавливаем параметры
        if (!empty($filter)) {
            $stmt->bindValue(':filter', '%' . $filter . '%');
        }

        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC); // Возвращаем все записи в виде ассоциативного массива
    } catch (PDOException $e) {
        echo "Ошибка при получении сотрудников: " . $e->getMessage();
        return [];
    }
}