<?php
require_once 'db.php'; // Подключение к базе данных
require_once 'functions.php'; // Подключение вспомогательных функций

// Получение ID сотрудника из GET параметров
$id = $_GET['id'] ?? null;

// Получение информации о сотруднике по ID

$employee = getEmployeeById($pdo, $id);

// Проверка на наличие сотрудника и его статус (уволен или нет)

if (!$employee || $employee['is_fired']) {
    echo "<div class='container'>";
    echo "<h1>Сотрудник не найден или уволен.</h1>";
    echo "<form action='index.php' method='GET'>";
    echo "<button type='submit' class='back-button'>Вернуться на главную</button>";
    echo "</form>";
    echo "</div>";
    exit(); // Остановка выполнения скрипта
}

// Обработка данных формы после её отправки методом POST

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = [
        'full_name' => $_POST['full_name'],
        'birth_date' => $_POST['birth_date'],
        'passport_number' => $_POST['passport_number'],
        'contact_info' => $_POST['contact_info'],
        'address' => $_POST['address'],
        'department' => $_POST['department'],
        'position' => $_POST['position'],
        'salary' => $_POST['salary'],
    ];

    // Обновление данных сотрудника в базе данных

    updateEmployee($pdo, $id, $data);

    // Перенаправление на главную страницу после обновления
    
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Редактирование сотрудника</title>
    <link rel="stylesheet" href="css/edit_employee.css"> 
</head>
<body>

    <!-- Основной контейнер -->
    <div class="container">
        <h1 class="main-heading">Редактировать сотрудника</h1>
        <form method="POST" class="employee-form">
            <div class="form-group">
                <label for="full_name">ФИО</label>
                <input type="text" name="full_name" value="<?= htmlspecialchars($employee['full_name']) ?>" required>
            </div>
            <div class="form-group">
                <label for="birth_date">Дата рождения</label>
                <input type="date" name="birth_date" value="<?= htmlspecialchars($employee['birth_date']) ?>" required>
            </div>
            <div class="form-group">
                <label for="passport_number">Паспорт</label>
                <input type="text" name="passport_number" value="<?= htmlspecialchars($employee['passport_number']) ?>" required pattern="\d{4} \d{6}" title="Формат: 0000 000000">
            </div>
            <div class="form-group">
                <label for="contact_info">Контакты</label>
                <input type="text" name="contact_info" value="<?= htmlspecialchars($employee['contact_info']) ?>" required pattern="\+7 \(\d{3}\) \d{3}-\d{2}-\d{2}" title="Формат: +7(999)999-99-99">
            </div>
            <div class="form-group">
                <label for="address">Адрес</label>
                <input type="text" name="address" value="<?= htmlspecialchars($employee['address']) ?>" required>
            </div>
            <div class="form-group">
                <label for="department">Отдел</label>
                <input type="text" name="department" value="<?= htmlspecialchars($employee['department']) ?>" required>
            </div>
            <div class="form-group">
                <label for="position">Должность</label>
                <input type="text" name="position" value="<?= htmlspecialchars($employee['position']) ?>" required>
            </div>
            <div class="form-group">
                <label for="salary">Зарплата</label>
                <input type="number" name="salary" value="<?= htmlspecialchars($employee['salary']) ?>" required>
            </div>

            <button type="submit" class="submit-button">Сохранить изменения</button>
        </form>

        <!-- Кнопка "Вернуться на главную" -->
        <form action="index.php" method="GET" style="display:inline;">
            <button type="submit" class="back-button">Вернуться на главную</button>
        </form>
    </div>

</body>
</html>