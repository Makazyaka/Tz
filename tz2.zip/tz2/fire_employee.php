<?php
require_once 'db.php'; // Подключение к базе данных
require_once 'functions.php'; // Подключение функций


// Проверка на наличие данных POST-запроса

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $employeeId = $_POST['id'];

    // Обновление статуса сотрудника на "уволен"
    $stmt = $pdo->prepare("UPDATE employees SET is_fired = 1 WHERE id = ?");
    $stmt->execute([$employeeId]);

    // Перенаправляем обратно на главную страницу
    header('Location: index.php');
    exit(); // Остановка выполнения скрипта
}
?>