<?php
require_once 'db.php'; // Подключение к базе данных
require_once 'functions.php'; // Подключение вспомогательных функций

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = [
        'full_name' => $_POST['full_name'],
        'birth_date' => $_POST['birth_date'],
        'passport_number' => $_POST['passport_number'],
        'contact_info' => $_POST['contact_info'],
        'address' => $_POST['address'],
        'department' => $_POST['department'],
        'position' => $_POST['position'],
        'salary' => $_POST['salary'],
        'hire_date' => $_POST['hire_date'],
    ];

    // Вызов функции для добавления сотрудника в базу данных
    addEmployee($pdo, $data);

    // Перенаправление на главную страницу после добавления
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/add_employee.css">
    <title>Добавление сотрудника</title>
</head>
<body>
    <div class="container">
        <h1 class="main-heading">Добавить нового сотрудника</h1>
        <form method="POST" class="employee-form">
            <div class="form-group">
                <label for="full_name">ФИО</label>
                <input type="text" name="full_name" placeholder="Введите ФИО" required>
            </div>

            <div class="form-group">
                <label for="birth_date">Дата рождения</label>
                <input type="date" name="birth_date" required>
            </div>

            <div class="form-group">
                <label for="passport_number">Серия и номер паспорта</label>
                <input type="text" name="passport_number" placeholder="Введите паспортные данные" required pattern="\d{4} \d{6}" title="Формат: 0000 000000">
            </div>

            <div class="form-group">
                <label for="contact_info">Контактная информация</label>
                <input type="text" name="contact_info" placeholder="Введите контактную информацию" required pattern="\+7 \(\d{3}\) \d{3}-\d{2}-\d{2}" title="Формат: +7(999)999-99-99">
            </div>

            <div class="form-group">
                <label for="address">Адрес проживания</label>
                <input type="text" name="address" placeholder="Введите адрес" required>
            </div>

            <div class="form-group">
                <label for="department">Отдел</label>
                <input type="text" name="department" placeholder="Введите отдел" required>
            </div>

            <div class="form-group">
                <label for="position">Должность</label>
                <input type="text" name="position" placeholder="Введите должность" required>
            </div>

            <div class="form-group">
                <label for="salary">Зарплата</label>
                <input type="number" name="salary" placeholder="Введите зарплату" required>
            </div>

            <div class="form-group">
                <label for="hire_date">Дата принятия на работу</label>
                <input type="date" name="hire_date" required>
            </div>

            <button type="submit" class="submit-button">Добавить сотрудника</button>
        </form>
        <button onclick="window.location.href='index.php'" class="back-button">Назад к списку сотрудников</button>
    </div>
</body>
</html>