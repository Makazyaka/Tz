<?php
require_once 'db.php'; // Подключение к базе данных
require_once 'functions.php'; // Подключение вспомогательных функций

$department = $_GET['department'] ?? null;
$position = $_GET['position'] ?? null;
$search = $_GET['search'] ?? null;

// Получение списка всех сотрудников из базы данных

$employees = getAllEmployees($pdo, $department, $position, $search);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Учет сотрудников</title>
    <link rel="stylesheet" href="css/index.css"> 
</head>
<body>

    <!-- Основной контейнер -->
    <div class="container">
        <h1 class="main-heading">Список сотрудников</h1>

        <!-- Форма поиска и фильтрации -->
        <form method="GET" class="employee-form">
            <div class="form-group">
                <label for="search">Поиск по ФИО</label>
                <input type="text" name="search" placeholder="Введите ФИО" value="<?= htmlspecialchars($search) ?>">
            </div>
            
            <div class="form-group">
                <label for="department">Отдел</label>
                <select name="department">
                    <option value="">Все отделы</option>
                    <option value="HR" <?= $department == 'HR' ? 'selected' : '' ?>>HR</option>
                    <option value="IT" <?= $department == 'IT' ? 'selected' : '' ?>>IT</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="position">Должность</label>
                <select name="position">
                    <option value="">Все должности</option>
                    <option value="Менеджер" <?= $position == 'Менеджер' ? 'selected' : '' ?>>Менеджер</option>
                    <option value="Разработчик" <?= $position == 'Разработчик' ? 'selected' : '' ?>>Разработчик</option>
                </select>
            </div>

            <button type="submit" class="submit-button">Применить фильтр</button>
        </form>

        <!-- Таблица сотрудников -->
        <table>
            <tr>
                <th>ФИО</th>
                <th>Дата рождения</th>
                <th>Паспорт</th>
                <th>Контакты</th>
                <th>Адрес</th>
                <th>Отдел</th>
                <th>Должность</th>
                <th>Зарплата</th>
                <th>Дата принятия</th>
                <th>Уволен</th>
                <th>Действия</th>
            </tr>
            <?php foreach ($employees as $employee): ?>
            <tr>
                <td><?= htmlspecialchars($employee['full_name']) ?></td>
                <td><?= htmlspecialchars($employee['birth_date']) ?></td>
                <td><?= htmlspecialchars($employee['passport_number']) ?></td>
                <td><?= htmlspecialchars($employee['contact_info']) ?></td>
                <td><?= htmlspecialchars($employee['address']) ?></td>
                <td><?= htmlspecialchars($employee['department']) ?></td>
                <td><?= htmlspecialchars($employee['position']) ?></td>
                <td><?= htmlspecialchars($employee['salary']) ?></td>
                <td><?= htmlspecialchars($employee['hire_date']) ?></td>
                <td><?= $employee['is_fired'] ? 'Да' : 'Нет' ?></td>
                <td>
                    <form action="edit_employee.php" method="GET" style="display:inline;">
                        <input type="hidden" name="id" value="<?= $employee['id'] ?>">
                        <button type="submit" class="edit-button">Редактировать</button>
                    </form>
                    
                    <?php if (!$employee['is_fired']): ?> <!-- Кнопка "Уволить" показывается только для тех, кто не уволен -->
                    <form action="fire_employee.php" method="POST" style="display:inline;">
                        <input type="hidden" name="id" value="<?= $employee['id'] ?>">
                        <button type="submit" class="fire-button">Уволить</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>

        <!-- Кнопка для добавления нового сотрудника -->
        <form action="add_employee.php" method="GET" style="display:inline;">
            <button type="submit" class="submit-button">Добавить нового сотрудника</button>
        </form>
    </div>

</body>
</html>